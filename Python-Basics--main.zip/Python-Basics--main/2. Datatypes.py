#int 
a = 12
print(a)
print(type(a))
#Float
b = 12.55
print(b)
print(type(b))
#String
c = "hello"
print(c)
print(type(c))
#Boolen 
x = True
y = False
print(x,y)
print(type(x))
print(type(y))
#complex 
d = 2+3j
print(d)
print(type(d))
#Casting 
#int
a1 = int(input("Enter a value:"))
print(a1)
print(type(a1))
#Float
b1 = float(input("Enter b value:"))
print(b1)
print(type(b1))
#String
c1 = str(input("Enter c value: "))
print(c1)
print(type(c1))
#Boolen 
x1 = bool(input("Enter x1 value:"))
y1 = bool(input("Enter y1 value:"))
print(x1,y1)
print(type(x1))
print(type(y1))
#complex 
d1 = complex(input("Enter the d1 values: "))
print(d1)
print(type(d1))

