#print is used for display the output in our program  
print("Hello World!")
#Bio - Data 
print("Name: Nandhan")
print("Branch: CSE-Ai&Ml")
print("Place: Kamareddy")
print("College: MRCET")
#Bio-Data Using input and output statements 
Name = input("Enter your name: ")
Age = input("Enter your age: ")
Branch = input("Enter your branch: ")
Place = input("Enter your place: ")
College = input("Enter your college name: ")
print("Name: ",Name)
print("Age: ",Age)
print("Branch: ",Branch)
print("Place: ",Place)
print("College: ",College)