file = open("student.txt","a")
# write, writelines
file.write("Hello c++\n")
text = b"Hello Nandhan"
file.close()