# # for varaible in sequence: 
#     #block of code to excute multiple times 
# # range(start v(d = 0), Stop v, step v d= 1)
# #in c for(int i = 0; i<=10; i+=2)
# # for i in range(2,11):
# #     print("square of ",i,i*i,)

# #print the squares of numbers from 1 to 10
# #for(int i = 10; i>0; i-=1)
# # for i in range(10,0,-1):
# #     print(i)
# #Print the numbers from 10 to 1
# for i in range(1,11):
#     print("7 x ",i,"=",7*i)

# # print the all even number upto 30
# # 0 2 4 6 8 10 .......
# for i in range(2,31,2):
#     print(i)
# # print the all odd number upto 30
# # 1 3 5 7 9 11 ........
# for i in range(2,31,2):
#     print(i)

# #print the numbers upto 29 using default values 
# for i in range(30):
#     print(i)

# list1 = [1,2,3,4,5] 
# for i in list1:
#     print(i,i+1)

# for i in "python":
#     print(i)

# # 1+2+3+4+.......+25=?
# total = 1
# for i in range(1,6):
#     total = total * i
# print(total)


# for i in range(10):
#     if i==5:
#         continue
#     print (i)

# break, continue, pass
for i in range(1,11):
    if i == 5:
        print(i)
    break 
